<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class ATMController extends Controller
{
     public function create()
    {
        
    }
}
